--{DatabaseName}
--{ForderData}
--{Year}

USE [master]
GO
/****** Object:  Database [{DatabaseName}]    Script Date: 18/08 11:48:43 ******/
CREATE DATABASE [{DatabaseName}]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'{DatabaseName}', FILENAME = N'{ForderData}\{DatabaseName}.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'{DatabaseName}_log', FILENAME = N'{ForderData}\{DatabaseName}_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [{DatabaseName}] MODIFY FILEGROUP [PRIMARY] AUTOGROW_ALL_FILES
GO
ALTER DATABASE [{DatabaseName}] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [{DatabaseName}].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ARITHABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [{DatabaseName}] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [{DatabaseName}] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [{DatabaseName}] SET  ENABLE_BROKER 
GO
ALTER DATABASE [{DatabaseName}] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [{DatabaseName}] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [{DatabaseName}] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [{DatabaseName}] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [{DatabaseName}] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [{DatabaseName}] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [{DatabaseName}] SET  MULTI_USER 
GO
ALTER DATABASE [{DatabaseName}] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [{DatabaseName}] SET DB_CHAINING OFF 
GO
ALTER DATABASE [{DatabaseName}] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [{DatabaseName}] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [{DatabaseName}] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [{DatabaseName}] SET QUERY_STORE = OFF
GO
USE [{DatabaseName}]
GO
/****** Object:  Table [dbo].[AlarmControlHistory]    Script Date: 18/08 11:48:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AlarmControlHistory](
	[ID] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NOT NULL,
	[IDDevice] [uniqueidentifier] NULL,
	[CopyID] [int] NOT NULL,
	[CopyIDDevice] [int] NOT NULL,
	[CopyAlarmHigh] [nvarchar](100) NOT NULL,
	[CopyAlarmLow] [nvarchar](100) NOT NULL,
	[CopyAlarmAPS] [nvarchar](100) NOT NULL,
	[CopyControlDevice] [int] NULL,
	[CopyCalib] [nvarchar](100) NULL,
	[Copydate_time] [datetime] NULL,
 CONSTRAINT [PK__AlarmCon__3214EC27FB1CD07F] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CommentMeasureData]    Script Date: 18/08 11:48:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CommentMeasureData](
	[ID] [uniqueidentifier] NOT NULL,
	[FromTime] [datetime] NOT NULL,
	[ToTime] [datetime] NOT NULL,
	[Comment] [nvarchar](1000) NULL,
	[IDDevice] [uniqueidentifier] NULL,
	[DevicePosition] [nvarchar](50) NULL,
	[UpdateTime] [datetime] NULL,
	[IsDelete] [bit] NULL,
	[CommentBy] [nvarchar](50) NULL,
 CONSTRAINT [PK_CommentMeasueData] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ConnectionHistory]    Script Date: 18/08 11:48:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ConnectionHistory](
	[ID] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NOT NULL,
	[Central] [nvarchar](100) NULL,
	[StatusSTSL] [int] NULL,
	[StatusSTSA] [int] NULL,
	[TimerConnectEnum] [int] NULL,
	[LastChangeStatusSTSL] [datetime] NULL,
	[LastChangeTimerConnect] [datetime] NULL,
	[LastChangeStatusSTSA] [datetime] NULL,
	[MessageNotify] [nvarchar](max) NULL,
	[TimerConnect] [nvarchar](100) NULL,
 CONSTRAINT [PK__Connecti__3214EC2771C305A2] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MeasureData]    Script Date: 18/08 11:48:44 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MeasureData](
	[ID] [uniqueidentifier] NOT NULL,
	[CreateTime] [datetime] NOT NULL,
	[IDDevice] [uniqueidentifier] NULL,
	[RawValue] [nvarchar](100) NULL,
	[Value] [decimal](18, 5) NULL,
	[APSValue] [decimal](18, 5) NULL,
	[Central] [nvarchar](100) NULL,
	[AO_Alarm] [int] NULL,
	[AG_Alarm] [int] NULL,
	[APS_Alarm] [int] NULL,
	[UW_Alarm] [int] NULL,
	[LockControlState1] [int] NULL,
	[LockControlState2] [int] NULL,
	[CalibMode] [int] NULL,
	[ChartCase] [int] NULL,
	[InputValue] [nvarchar](50) NULL,
	[AO_Config] [decimal](18, 5) NULL,
	[AG_Config] [decimal](18, 5) NULL,
	[StatusSTSA] [int] NULL,
	[StatusSTSL] [int] NULL,
 CONSTRAINT [PK__MeasureD__3214EC27E1AF5FDC] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [idx_AlarmControlHistory_device_createTime]    Script Date: 18/08 11:48:44 ******/
CREATE NONCLUSTERED INDEX [idx_AlarmControlHistory_device_createTime] ON [dbo].[AlarmControlHistory]
(
	[CreateTime] ASC,
	[IDDevice] ASC
)
INCLUDE([CopyID],[CopyIDDevice],[CopyAlarmHigh],[CopyAlarmLow],[CopyAlarmAPS],[CopyControlDevice],[CopyCalib],[Copydate_time]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [idx_CommentMeasureData_device_createTime]    Script Date: 18/08 11:48:44 ******/
CREATE NONCLUSTERED INDEX [idx_CommentMeasureData_device_createTime] ON [dbo].[CommentMeasureData]
(
	[FromTime] ASC,
	[ToTime] ASC,
	[IDDevice] ASC
)
INCLUDE([Comment],[DevicePosition],[UpdateTime],[IsDelete],[CommentBy]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [idx_ConnectionHistory_device_createTime]    Script Date: 18/08 11:48:44 ******/
CREATE NONCLUSTERED INDEX [idx_ConnectionHistory_device_createTime] ON [dbo].[ConnectionHistory]
(
	[CreateTime] ASC
)
INCLUDE([Central],[StatusSTSL],[StatusSTSA],[TimerConnectEnum],[LastChangeStatusSTSL],[LastChangeTimerConnect],[LastChangeStatusSTSA],[MessageNotify],[TimerConnect]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [idx_MeasureData_createTime_device]    Script Date: 18/08 11:48:44 ******/
CREATE NONCLUSTERED INDEX [idx_MeasureData_createTime_device] ON [dbo].[MeasureData]
(
	[CreateTime] ASC,
	[IDDevice] ASC
)
INCLUDE([RawValue],[Value],[APSValue],[Central],[AO_Alarm],[AG_Alarm],[APS_Alarm],[UW_Alarm],[LockControlState1],[LockControlState2],[CalibMode],[ChartCase],[InputValue],[AO_Config],[AG_Config],[StatusSTSA],[StatusSTSL]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
USE [master]
GO
ALTER DATABASE [{DatabaseName}] SET  READ_WRITE 
GO
